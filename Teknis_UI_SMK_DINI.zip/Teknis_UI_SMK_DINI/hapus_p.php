<?PHP
$no=$_GET['no'];
include ('koneksi.php');

$sql="DELETE from data_pegawai WHERE no='$no'";
mysql_query($sql) or die('salah');
header ('location:lembaga.php');
?>