<?php
session_start();
include 'koneksi.php';
$username_login=$_POST ['username_admin'];
$password_login=$_POST ['password_admin'];

$sql="SELECT * FROM admin WHERE username_admin='$username_login' ";
$data=mysql_query($sql);

while ($tampil=mysql_fetch_array($data)) {
$no_admin=$tampil['no_admin'];
$username_admin=$tampil['username_admin'];
$password_admin=$tampil['password_admin'];
$level=$tampil['level'];

if (MD5($password_login)==$password_admin) { 
echo "SUKSES LOGIN";
session_start();
$_SESSION['no_admin']=$no_admin;
$_SESSION['username_admin']=$username_login;
$_SESSION['level']=$level;

header('location:index.php');
} else {
echo "GAGAL LOGIN";
header('location:login.php');
}
}


?>