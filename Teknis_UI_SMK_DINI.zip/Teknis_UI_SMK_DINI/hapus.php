<?PHP
$no=$_GET['no'];
include ('koneksi.php');

$sql="DELETE from pegawai WHERE no='$no'";
mysql_query($sql) or die('salah');
header ('location:index.php');
?>