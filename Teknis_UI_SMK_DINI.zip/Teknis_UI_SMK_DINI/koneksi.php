<?php

$host="localhost";
$user="root";
$pass="semarang";
$database="pns"; 

$conn = mysql_connect($host,$user,$pass);
//jika konek dengan server
if ($conn) {
$buka = mysql_select_db($database);
//jika database tidak dapat dipanggil
if (!$buka){
die ("Database tidak dapat dibuka");
}
}else{
#jika server tidak konek
die ("Server MySQL tidak terhubung");
}


?>
