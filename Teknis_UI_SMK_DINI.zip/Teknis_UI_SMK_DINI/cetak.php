<?php
session_start();
include 'koneksi.php';
$no=$_GET['no'];
$html .= '
<html>
<head>
<style>
p{
color: #F00E0E;
text-decoration: none;
}
h2{
color: #F00E0E;
text-decoration: none;
}
body {font-family: sans-serif;
	font-size: 12pt;
	background: transparent url(\'image/bgbarcode.png\') repeat-y scroll left top;
}
h5, p {	margin: 0pt;
}

h3 {
font-size: 16px;}
table{
	font-size: 9pt; 
	border-collapse: collapse;
	border: 0px ; 
	margin-bottom: 20px;
	
}
table.format1{
	font-size: 9pt; 
	border-collapse: collapse;
	border: 0px ; 
	margin-left: 500px;
	
}
td { vertical-align: top;
}
table thead td { background-color: #EEEEEE;
	text-align: center;
}
table tfoot td { background-color: #AAFFEE;
	text-align: center;
}

.barcode {
	padding: 1.5mm;
	margin: 0;
	vertical-align: top;
	color: #000000;
}
.code {
	text-align: left;
	padding: 10px;
}
.barcodecell {
	text-align: center;
	vertical-align: middle;
	padding: 0;
}
</style>
</head>
<body>';
						
	$sql="SELECT * FROM pegawai ";
	$data=mysql_query($sql);
	$tampil=mysql_fetch_array($data);
	$no=$tampil['no'];
	$nip=$tampil['nip'];;
	$nama=$tampil['nama'];
	$pangkatgol=$tampil['pangkatgol'];
	$jabatan=$tampil['jabatan'];
	$unit_kerja=$tampil['unit_kerja'];
	$tipe_pekerjaan=$tampil['tipe_pekerjaan'];
	$gambar=$tampil['gambar'];
	
$html .="
							<center><h3>Daftar Pegawai PNS</h3></center>
	  <table border='0' width='78%' cellpadding='8px'>
		
		<tr>
	  <td>No</td><td>:</td><td>".$tampil['no']."</td></tr>
	  <tr>
	  <td>Nip</td><td>:</td><td>".$tampil['nip']."</td></tr>
	  <tr>
	  <td>Nama</td><td>:</td><td>".$tampil['nama']."</td></tr>
	  <tr>
	  <td>Pangkat.Gol</td><td>:</td><td>".$tampil['pangkatgol']."</td></tr>
	  <tr>
	  <td>Jabatan</td><td>:</td><td>".$tampil['jabatan']."</td></tr>
	  <tr>
	  <td>Unit Kerja</td><td>:</td><td>".$tampil['unit_kerja']."</td></tr>
	  <tr>
	  <td>Tipe Pekerjaan</td><td>:</td><td>".$tampil['tipe_pekerjaan']."</td></tr>
	  <tr>
	  <td>Foto Pegawai</td><td>:</td><td><img src='".$tampil['gambar']."' width='50' height='50'></td></tr>
	  </table>
	  ";
include("PDF/mpdf.php");

$mpdf=new mPDF(); 
$mpdf->WriteHTML($html);
$mpdf->Output(); 
//==============================================================
//==============================================================
exit;			
?></td></tr>
			
	</table>



