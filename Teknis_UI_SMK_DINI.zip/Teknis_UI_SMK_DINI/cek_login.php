<?php 

session_start();
		if (empty($_SESSION['no_admin'])) {
		header('location:login.php');
}else {
		if (empty($_SESSION['username_admin'])){
		header('location:login.php');
		}
	
}

?>